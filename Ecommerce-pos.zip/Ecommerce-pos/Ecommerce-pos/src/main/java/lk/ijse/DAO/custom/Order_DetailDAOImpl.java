package lk.ijse.DAO.custom;
import lk.ijse.DAO.SuperDAO;

public class Order_DetailDAOImpl implements SuperDAO {


}
