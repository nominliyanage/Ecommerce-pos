package lk.ijse.DTO;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class LoginDTO {
    private int login;
    private String UserMail;
}
