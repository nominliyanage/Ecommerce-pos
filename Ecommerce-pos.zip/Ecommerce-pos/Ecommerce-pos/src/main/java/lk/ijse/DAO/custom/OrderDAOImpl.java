package lk.ijse.DAO.custom;
import lk.ijse.DAO.SuperDAO;

public class OrderDAOImpl implements SuperDAO {


}
