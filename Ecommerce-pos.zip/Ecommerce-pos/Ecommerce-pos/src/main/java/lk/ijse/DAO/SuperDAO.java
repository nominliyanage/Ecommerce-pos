package lk.ijse.DAO;

public interface SuperDAO {
}
