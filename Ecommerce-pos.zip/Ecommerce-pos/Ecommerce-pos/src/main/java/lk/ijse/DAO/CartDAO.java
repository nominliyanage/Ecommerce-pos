package lk.ijse.DAO;

import lk.ijse.Entity.Cart;

public interface CartDAO extends CrudDAO<Cart> {
}
